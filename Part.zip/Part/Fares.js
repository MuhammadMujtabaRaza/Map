import React from 'react';
import { StyleSheet , Text, View, Button } from 'react-native';

export default function Fares({ route }) {
  const { pickup, destination } = route.params;

  const fares = {
    bike: 70,
    rickshaw: 100,
    car:250,
  };

  const calcCrow = (lat1, lon1, lat2, lon2) => {
    const R = 6371; // km
    const toRad = (Value) => Value * Math.PI / 180;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const lat1Rad = toRad(lat1);
    const lat2Rad = toRad(lat2);

    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1Rad) * Math.cos(lat2Rad);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c;

    return distance;
  };

  const calculateFare = (vehicle) => {
    const { latitude: pickupLat, longitude: pickupLong } = pickup.geocodes.main;
    const { latitude: destinationLat, longitude: destinationLong } = destination.geocodes.main;

    const distance = calcCrow(pickupLat, pickupLong, destinationLat, destinationLong);

    const fare = fares[vehicle] * distance;
    console.log(distance);
    alert('Rs. ' + fare.toFixed(2));
  };

  return (
    <View>
      <Text id='abc'>Your Pickup Location is: {pickup.name} {pickup.location.address}</Text>
      <Text>Your Destination is: {destination.name} {destination.location.address}</Text>
      <Text>Select Fare</Text>

      <View>
        <Button onPress={() => calculateFare('bike')} title={`Bike | ${fares.bike} Rs. / Km`} />
        <Button onPress={() => calculateFare('rickshaw')} title={`Rickshaw | ${fares.rickshaw} Rs. / Km`} />
        <Button onPress={() => calculateFare('car')} title={`Car | ${fares.car} Rs. / Km`} />
      </View>
    </View>
  );
}
